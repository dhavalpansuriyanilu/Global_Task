//
//  HomeVC.swift
//  ImageProcessing
//
//  Created by Developer 1 on 09/11/23.
//

import UIKit

class HomeVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
        
    @IBAction func photoFilterAction(_ sender: UIButton) {
//        performSegue(withIdentifier: "photoSegue", sender: self)
    }
    
    @IBAction func videoFilterAction(_ sender: UIButton) {
//        performSegue(withIdentifier: "VideoSegue", sender: self)
    }
}
