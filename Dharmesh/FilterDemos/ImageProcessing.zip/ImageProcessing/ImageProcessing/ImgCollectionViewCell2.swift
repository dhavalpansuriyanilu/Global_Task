//
//  ImgCollectionViewCell2.swift
//  ImageProcessing
//
//  Created by Developer 1 on 07/11/23.
//

import UIKit

class ImgCollectionViewCell2: UICollectionViewCell {
    @IBOutlet weak var filterimg: UIImageView!
}
